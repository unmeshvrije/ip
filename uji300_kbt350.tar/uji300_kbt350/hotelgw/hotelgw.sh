#!
cd ./bin
java  HotelGateway
