import java.rmi.Naming;

import java.rmi.RemoteException;
import java.rmi.AccessException;
import java.net.MalformedURLException;

public class HotelReservationServer {
	
	private static final String argServerNameURL = "rmi://localhost/HotelReserver";
	public HotelReservationServer()
	{
		try
		{
			IReserver hotelReserver = new Reserver();
			Naming.rebind(argServerNameURL, hotelReserver);
		}
	    catch (MalformedURLException e)
	    {
	      System.out.println(argServerNameURL + "is not a valid RMI URL");
	    }
	    catch (AccessException e)
	    {
	     System.out.println("AccessException occured");
	    }
	    catch (RemoteException e)
	    {
	     System.out.println("RemoteException occured");
	    }
		catch (Exception e)
		{
			System.out.println("Error in initializing the hotel reserver.");
			e.printStackTrace();
		}
	}
	
	public static void main(String args[])
	{
		new HotelReservationServer();
	}

}
