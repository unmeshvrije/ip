
public class BookingRecord {

	String guestName;
	Room room;
	
	public BookingRecord(String guestName, Room room)
	{
		this.guestName = guestName;
		this.room = room;
	}
	
}
