
public enum RoomType {

	ONE, TWO, THREE, INVALID;
}
