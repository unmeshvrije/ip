#!/usr/bin/bash
cd bin/
java -cp ${PWD} HotelReservationServer
