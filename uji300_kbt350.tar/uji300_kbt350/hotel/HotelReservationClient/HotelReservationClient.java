/*++

Module Name:
        HotelReservationClient.java

Abstract:
        This module implements the client for working with the hotel reservation server.

Revision History:
        Date    : Oct 12 2012.

        Author  : Unmesh Joshi (S-2515965).
                : Koustubha Bhat (S-2516144).

        VUnetID : uji300
                : kbt350

        Desc    : Created.
        
--*/

import java.rmi.Naming;

import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;



public class HotelReservationClient {
	
	private enum Command
	{
		INVALID, LIST, BOOK, GUESTS;
	}
	
	private static String argServerName;
	private static Command operation;
	private static String operationArg;
	private static int iRoomType;
	private static int mandatoryArgLength;
	private static int optionalArgLength;
	
	private static boolean cmdLineValidateAndSet(String[] args)
	{
		argServerName = "";
		operation = Command.INVALID;
		operationArg = new String();			
		mandatoryArgLength = 2;
		optionalArgLength = 2;
		
		if (args.length < mandatoryArgLength )
		{
			return false;
		}
		
		argServerName = args[0];
	
		if (args[1].equalsIgnoreCase("list"))
		{
			operation = Command.LIST;
			return true;
		}
		else if (args[1].equalsIgnoreCase("guests"))
		{
			operation = Command.GUESTS;
			return true;
		}
		else if (args[1].equalsIgnoreCase("book"))
		{
			if (args.length < (mandatoryArgLength + optionalArgLength))
			{
				return false;
			}
			operation = Command.BOOK;

			try
			{
				iRoomType = Integer.parseInt(args[2]);
			}
			catch(NumberFormatException ne)
			{
				return false;
			}

			if ((iRoomType <= 0) || (iRoomType > 3))
			{
				return false;
			}
			
			operationArg = args[3];
			// Guest's name, which should support being space separated
			for(int i=4; i<args.length; i++)
			{
				operationArg += " " + args[i];
			}
			return true;
		}
		return false;
	}

	private static void displayUsage()
	{
		System.out.println("\nUsage: HotelReservationClient <server_name> <command> [<arguments>]");
		System.out.println("Commands");
		System.out.println("\tlist\t- lists the availability of rooms for first, second and third type rooms");
		System.out.println("\tbook\t- books the specified <kind of room> for the particular <guest>. e.g.: book 1 John");
		System.out.println("\tguests\t- lists the guests who have been allocated rooms already.\n");
	}

	public static void main(String[] args)
	{
		try
		{
			if (false == cmdLineValidateAndSet(args))
			{
				displayUsage();
				return;
			}

			IReserver reservationClient = (IReserver)Naming.lookup("rmi://" + argServerName + "/HotelReserver");

			switch (operation)
			{
			
			case LIST:
				System.out.print(reservationClient.list());
				break;
			
			case BOOK:
				if (true == reservationClient.book(iRoomType, operationArg))
				{
					System.out.println("Booking successful.");
				}
				break;
			
			case GUESTS:
				String[] guests = reservationClient.guests();
				for(int i=0; (i < guests.length) && (guests[i]!= null); i++)
				{
					System.out.println(guests[i]);
				}
				break;
			}
			
		}
	    catch (MalformedURLException e)
	    {
	      System.out.println(argServerName + "is not a valid RMI URL");
	    }
	    catch (RemoteException e)
	    {
	     System.out.println("Remote object threw exception ");
	    }
	    catch (NotBoundException e)
	    {
	      System.out.println("Could not find the requested remote object on the server");
	    }
		catch (Exception e)
		{
			System.out.println("Exception caught in the main() of client program.");
			e.printStackTrace();
		}
	}
}
