for i in {1..5}
do
  # echo "$i:"
   ./client $1 >> client.txt
done
